
struct expression {
    int nargs;
    struct expression *args[3];
};

struct expression plvar = {0};

